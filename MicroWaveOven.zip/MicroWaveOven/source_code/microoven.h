/* 
 * File:   microoven.h
 * Author: sirisha
 *
 * Created on February 26, 2025, 10:01 PM
 */

#ifndef MICROOVEN_H
#define	MICROOVEN_H

void power_on_screen(void);
void clear_screen(void);
void display_menu_scren(void);
void set_time(unsigned char key,unsigned char reset_flag);
void set_temp(unsigned char key,unsigned char reset_flag);
void heat_food(void);


void time_display(void); 
#endif	/* MICROOVEN_H */

